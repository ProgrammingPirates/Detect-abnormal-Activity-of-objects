// API Service for WiFi-DensePose UI

import { API_CONFIG, buildApiUrl } from '../config/api.config.js';
import { backendDetector } from '../utils/backend-detector.js';

export class ApiService {
  constructor() {
    this.authToken = null;
    this.requestInterceptors = [];
    this.responseInterceptors = [];
  }

  // Set authentication token
  setAuthToken(token) {
    this.authToken = token;
  }

  // Add request interceptor
  addRequestInterceptor(interceptor) {
    this.requestInterceptors.push(interceptor);
  }

  // Add response interceptor
  addResponseInterceptor(interceptor) {
    this.responseInterceptors.push(interceptor);
  }

  // Build headers for requests
  getHeaders(customHeaders = {}) {
    const headers = {
      ...API_CONFIG.DEFAULT_HEADERS,
      ...customHeaders
    };

    if (this.authToken) {
      headers['Authorization'] = `Bearer ${this.authToken}`;
    }

    return headers;
  }

  // Process request through interceptors
  async processRequest(url, options) {
    let processedUrl = url;
    let processedOptions = options;

    for (const interceptor of this.requestInterceptors) {
      const result = await interceptor(processedUrl, processedOptions);
      processedUrl = result.url || processedUrl;
      processedOptions = result.options || processedOptions;
    }

    return { url: processedUrl, options: processedOptions };
  }

  // Process response through interceptors
  async processResponse(response, url) {
    let processedResponse = response;

    for (const interceptor of this.responseInterceptors) {
      processedResponse = await interceptor(processedResponse, url);
    }

    return processedResponse;
  }

  // Generic request method
  async request(url, options = {}) {
    try {
      // Process request through interceptors
      const processed = await this.processRequest(url, options);

      // Determine the correct base URL (real backend vs mock)
      let finalUrl = processed.url;
      if (processed.url.startsWith(API_CONFIG.BASE_URL)) {
        const baseUrl = await backendDetector.getBaseUrl();
        finalUrl = processed.url.replace(API_CONFIG.BASE_URL, baseUrl);
      }
      
      // Make the request
      const response = await fetch(finalUrl, {
        ...processed.options,
        headers: this.getHeaders(processed.options.headers)
      });

      // Process response through interceptors
      const processedResponse = await this.processResponse(response, url);

      // NOTE: there is deliberately no step-up re-authentication branch here.
      //
      // An earlier revision caught the server's RFC 6750 "reauthentication
      // required" challenge and redirected to /oauth/start. That challenge can
      // never be issued to a browser: browser sign-in requests `sensing:read`
      // only and always will (see BROWSER_SIGNIN_SCOPE), so no browser session
      // holds `sensing:admin`, so the freshness gate the challenge announces is
      // never reached. Admin work goes through the CLI or a pasted bearer.
      //
      // Removed rather than left inert, because it was not merely dead — it
      // ended in a promise that never settles. If any other 401 ever grew that
      // header, every caller awaiting this would hang forever with no error.
      // The server-side guard stays as a fail-closed backstop; the client has
      // nothing to do about a flow that does not exist.

      // Handle errors
      if (!processedResponse.ok) {
        const error = await processedResponse.json().catch(() => ({
          message: `HTTP ${processedResponse.status}: ${processedResponse.statusText}`
        }));
        throw new Error(error.message || error.detail || 'Request failed');
      }

      // Parse JSON response
      const data = await processedResponse.json().catch(() => null);
      return data;

    } catch (error) {
      // Only log if not a connection refusal (expected when DensePose API is down)
      if (error.message && !error.message.includes('Failed to fetch')) {
        console.error('API Request Error:', error);
      }
      throw error;
    }
  }

  // GET request
  async get(endpoint, params = {}, options = {}) {
    const url = buildApiUrl(endpoint, params);
    return this.request(url, {
      method: 'GET',
      ...options
    });
  }

  // POST request
  async post(endpoint, data = {}, options = {}) {
    const url = buildApiUrl(endpoint);
    return this.request(url, {
      method: 'POST',
      body: JSON.stringify(data),
      ...options
    });
  }

  // PUT request
  async put(endpoint, data = {}, options = {}) {
    const url = buildApiUrl(endpoint);
    return this.request(url, {
      method: 'PUT',
      body: JSON.stringify(data),
      ...options
    });
  }

  // DELETE request
  async delete(endpoint, options = {}) {
    const url = buildApiUrl(endpoint);
    return this.request(url, {
      method: 'DELETE',
      ...options
    });
  }
}

// Create singleton instance
export const apiService = new ApiService();

// Storage key shared with the QuickSettings "API Access" panel.
export const API_TOKEN_STORAGE_KEY = 'ruview-api-token';

// Apply a previously-saved bearer token at module load — before app init
// dispatches its first request — so a configured RUVIEW_API_TOKEN works from
// the very first /api/v1/* call. The server only ever checks the
// `Authorization: Bearer` header (see bearer_auth.rs) — this intentionally
// never puts the token in a URL query string.
try {
  const storedToken = localStorage.getItem(API_TOKEN_STORAGE_KEY);
  if (storedToken) apiService.setAuthToken(storedToken);
} catch { /* storage unavailable (private browsing etc.) */ }